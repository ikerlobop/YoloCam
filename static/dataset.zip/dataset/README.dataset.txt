# carbon fiber defect > 2024-03-03 12:10pm
https://universe.roboflow.com/carbonfibredefect/carbon-fiber-defect

Provided by a Roboflow user
License: CC BY 4.0

